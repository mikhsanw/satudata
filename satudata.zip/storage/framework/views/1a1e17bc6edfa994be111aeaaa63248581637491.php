
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xl-12">
            <div id="panel-1" class="panel">
                <div class="panel-hdr">
                    <h2>
                        <span class="fa fa-home"></span> &nbsp;Beranda
                    </h2>
                    <div class="panel-toolbar">
                        <div class="btn-group">
                        
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.home.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\satudata\resources\views/backend/beranda/index.blade.php ENDPATH**/ ?>