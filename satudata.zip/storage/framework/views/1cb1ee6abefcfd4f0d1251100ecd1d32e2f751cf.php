
<?php $__env->startPush('title',ucwords(strtolower($halaman->nama))); ?>
<?php $__env->startPush('header',ucwords(strtolower($halaman->nama))); ?>
<?php $__env->startPush('tombol'); ?>
<a href="#tambah" class="btn btn-sm btn-primary tambah-profil">
	Tambah  <i class="fa fa-plus-circle"></i>
</a>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="panel-container show">
	<div class="panel-content">
		<table id="datatable" class="table table-bordered table-hover table-striped w-100">
			<thead class="bg-primary-600">
				<tr>
					<th class="width-1">No</th>
					<th class="text-center">Menu</th>
					<th class="text-center">Kelola</th>
					<th width="50px" class="text-center" tabindex="0" rowspan="1" colspan="1">Aksi</th>
				</tr>
			</thead>
		</table>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<?php echo $__env->make('backend.home.datatable-js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script type="text/javascript" src="<?php echo e(URL::asset(config('master.aplikasi.author').'/home/'.$halaman->link.'/'.$halaman->kode.'/jquery-crud.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset(config('master.aplikasi.author').'/'.$halaman->kode.'/'.$data->id.'/datatables_detail.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset(config('master.aplikasi.author').'/'.$halaman->kode.'/jquery.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset(config('master.aplikasi.author').'/'.$halaman->kode.'/'.$data->id.'/jquery-detail.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('backend/js/formplugins/select2/select2.bundle.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('css'); ?>
<link rel="stylesheet" media="screen, print" href="<?php echo e(URL::asset('backend/css/formplugins/select2/select2.bundle.css')); ?>">
<link rel="stylesheet" media="screen, print" href="<?php echo e(asset('backend/css/formplugins/summernote/summernote.css')); ?>">
<?php echo $__env->make('backend.home.datatable-css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.home.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\satudata\resources\views/backend/elemen/detail.blade.php ENDPATH**/ ?>