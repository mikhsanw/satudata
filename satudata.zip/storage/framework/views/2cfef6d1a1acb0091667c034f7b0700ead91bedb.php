$(document).ready(function () {
	$('.select2').select2(
		{
			placeholder: "- Pilih -",
			allowClear: true
		}
	);

	var controls = {
        leftArrow: '<i class="fal fa-angle-left" style="font-size: 1.25rem"></i>',
        rightArrow: '<i class="fal fa-angle-right" style="font-size: 1.25rem"></i>'
    }
})<?php /**PATH C:\xampp\htdocs\satudata\resources\views/backend/wilayah/ajax.blade.php ENDPATH**/ ?>