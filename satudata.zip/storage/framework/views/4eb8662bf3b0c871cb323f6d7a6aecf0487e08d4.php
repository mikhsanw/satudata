$(document).ready(function() {
	$('#datatable').DataTable({
		responsive: true,
		serverside: true,
		lengthChange: false,
		language: {
            url: "<?php echo e(asset('resources/vendor/datatables/js/indonesian.json')); ?>"
        },
		processing: true,
		serverSide: true,
		ajax: "<?php echo e(url($url_admin.'/'.$kode.'/data')); ?>",
		columns: [
                { data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false },
				{ data: 'nama' },
				{ data: 'tingkatandaerah' },
				{ data: 'action', orderable: false, searchable: false}
		    ]
    });
});
<?php /**PATH C:\xampp\htdocs\satudata\resources\views/backend/laporan/datatables.blade.php ENDPATH**/ ?>