<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <?php if($aplikasi->file_favicon): ?>
        <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset($aplikasi->file_favicon->url_stream)); ?>">
        <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset($aplikasi->file_favicon->url_stream)); ?>">
    <?php endif; ?>
    <meta name="description" content="<?php echo ucwords(strtolower(($aplikasi->nama??'').' '.($aplikasi->daerah??''))); ?>">
    <title><?php echo $__env->yieldPushContent('title','Home'); ?> | <?php echo e($aplikasi->singkatan??''); ?></title>
    <meta name="csrf-token" content="<?php echo csrf_token(); ?>">
    <meta name="author" content="<?php echo config('master.aplikasi.author'); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no, user-scalable=no, minimal-ui">
    <meta name="apple-mobile-web-app-capable" content="yes"/>
    <meta name="msapplication-tap-highlight" content="no">
    <link rel="stylesheet" media="screen, print" href="<?php echo e(asset('backend/css/vendors.bundle.css')); ?>">
    <link rel="stylesheet" media="screen, print" href="<?php echo e(asset('backend/css/app.bundle.css')); ?>">
    <link rel="mask-icon" href="<?php echo e(asset('backend/img/favicon/safari-pinned-tab.svg')); ?>" color="#5bbad5">
    <link rel="stylesheet" media="screen, print" href="<?php echo e(asset('resources/vendor/font-awesome/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backend/css/all.css')); ?>"/>
    <link rel="stylesheet" media="screen, print" href="<?php echo e(asset('resources/css/sweetalert2/sweetalert2.bundle.css')); ?>">
    <?php if(config('master.aplikasi.tema') != NULL): ?>
        <link id="mytheme" rel="stylesheet" media="screen, print" href="<?php echo e(asset('backend/css/themes/cust-theme-'.config('master.aplikasi.tema').'.css')); ?>">
    <?php endif; ?>
    <link id="myskin" rel="stylesheet" media="screen, print" href="<?php echo e(asset('backend/css/skin/skin-master.css')); ?>">
    <?php echo $__env->yieldPushContent('css'); ?>






















</head>
<body class="mod-bg-1 nav-function-fixed mod-nav-dark mod-nav-link">
<script>
    'use strict';
    let classHolder = document.getElementsByTagName("BODY")[0],
        themeSettings = (localStorage.getItem('themeSettings')) ? JSON.parse(localStorage.getItem('themeSettings')) : {},
        themeURL = themeSettings.themeURL || '',
        themeOptions = themeSettings.themeOptions || '';

    if (themeSettings.themeOptions) {
        classHolder.className = themeSettings.themeOptions;
    }
    if (themeSettings.themeURL && !document.getElementById('mytheme')) {
        let cssfile = document.createElement('link');
        cssfile.id = 'mytheme';
        cssfile.rel = 'stylesheet';
        cssfile.href = themeURL;
        document.getElementsByTagName('head')[0].appendChild(cssfile);

    } else if (themeSettings.themeURL && document.getElementById('mytheme')) {
        document.getElementById('mytheme').href = themeSettings.themeURL;
    }

    let saveSettings = function () {
        themeSettings.themeOptions = String(classHolder.className).split(/[^\w-]+/).filter(function (item) {
            return /^(nav|header|footer|mod|display)-/i.test(item);
        }).join(' ');
        if (document.getElementById('mytheme')) {
            themeSettings.themeURL = document.getElementById('mytheme').getAttribute("href");
        }
        localStorage.setItem('themeSettings', JSON.stringify(themeSettings));
    };

    let resetSettings = function () {
        localStorage.setItem("themeSettings", "");
    };
</script>
<div class="page-wrapper">
    <div class="page-inner">
        <?php echo $__env->make('backend.home.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="page-content-wrapper">
            <?php echo $__env->make('backend.home.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <main id="js-page-content" role="main" class="page-content">
                <ol class="breadcrumb page-breadcrumb">
                    <li class="position-absolute pos-top pos-right d-none d-sm-block">
                        <?php echo e($fungsi->getHari()); ?>, <?php echo e($fungsi->tanggalIndonesia()); ?>

                    </li>
                </ol>
                <?php if(is_null($halaman)): ?>
                    <?php echo $__env->yieldContent('content'); ?>
                <?php else: ?>
                    <?php if($halaman->detail): ?>
                        <?php echo $__env->make('backend.home.sidebar_item.informasi',['judul'=>($halaman->detail['title'] ?? ''),'keterangan'=>($halaman->detail['keterangan'] ?? ''),'status_pengumuman'=>($halaman->detail['status_pengumuman'] ?? '')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>
                    <div class="row">
                        <div class="col-xl-12">
                            <div id="panel-1" class="panel">
                                <div class="panel-hdr">
                                    <h2>
                                        <span class="fa <?php echo $halaman->icon ?? 'fa-home'; ?>"></span> &nbsp;
                                        <?php echo $__env->yieldPushContent('header'); ?>
                                    </h2>
                                    <?php echo $__env->yieldPushContent('panel'); ?>
                                    <div class="panel-toolbar">
                                        <div class="btn-group">
                                        <a href="<?php echo e(URL::previous()); ?>" class="btn btn-sm btn-info kembali">
                                           <i class="fa fa-arrow-circle-left"></i> Kembali
                                        </a>
                                        </div>&nbsp;&nbsp;
                                        <div class="btn-group">
                                            <?php echo $__env->yieldPushContent('tombol'); ?>
                                        </div>
                                    </div>
                                </div>
                                <?php echo $__env->yieldContent('content'); ?>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </main>
            <div class="page-content-overlay" data-action="toggle" data-class="mobile-nav-on"></div>
            <?php echo $__env->make('backend.home.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <?php echo $__env->make('backend.home.sidebar_item.setting', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<script src="<?php echo e(asset('backend/js/vendors.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/app.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('resources/vendor/jquery/blockUI.js')); ?>"></script>
<script src="<?php echo e(asset('resources/vendor/jquery/jquery.loadmodal.js')); ?>"></script>
<script src="<?php echo e(asset(config('master.aplikasi.author').'/home/jquery.js')); ?>"></script>
<script src="<?php echo e(asset('resources/vendor/sweetalert2/sweetalert2.bundle.js')); ?>"></script>

<?php echo $__env->yieldPushContent('js'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\satudata\resources\views/backend/home/index.blade.php ENDPATH**/ ?>