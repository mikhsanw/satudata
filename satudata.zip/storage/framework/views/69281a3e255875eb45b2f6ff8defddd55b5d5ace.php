<!DOCTYPE html>
<html dir="ltr" lang="en-US">
<head>

	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="author" content="<?php echo e($aplikasi->singkatan); ?>" />
	<meta name="description" content="<?php echo e($aplikasi->singkatan.' '.$aplikasi->daerah); ?> - <?php echo $__env->yieldContent('title'); ?>" />
	<link rel="canonical" href="<?php echo e(url()->full()); ?>" />
	<meta property="og:locale" content="id_ID" />
	<meta property="og:type" content="article" />
	<meta property="og:title" content="<?php echo $__env->yieldContent('title'); ?>" />
	<meta property="og:description" content="<?php echo e($aplikasi->singkatan.' '.$aplikasi->daerah); ?> - <?php echo $__env->yieldContent('title'); ?>" />
	<meta property="og:url" content="<?php echo e(url()->full()); ?>" />
	<meta property="og:site_name" content="<?php echo e($aplikasi->singkatan.' '.$aplikasi->daerah); ?> - <?php echo $__env->yieldContent('title'); ?>" />
	<meta property="article:modified_time" content="<?php echo e(date('Y-m-d H:i:s')); ?>" />
	<meta property="og:image" content="<?php echo $__env->yieldContent('img'); ?>" />
	<meta name="twitter:card" content="summary" />
	<meta name="twitter:label1" content="Est. reading time" />
	<meta name="twitter:data1" content="3 minutes" />

	<!-- Stylesheets
	============================================= -->
	<link href="https://fonts.googleapis.com/css?family=Lato:300,400,400i,700|Poppins:300,400,500,600,700|PT+Serif:400,400i&display=swap" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" href="<?php echo e(URL::asset('frontend/css/bootstrap.css')); ?>" type="text/css" />
	<link rel="stylesheet" href="<?php echo e(URL::asset('frontend/style.css')); ?>" type="text/css" />
	<link rel="stylesheet" href="<?php echo e(URL::asset('frontend/css/dark.css')); ?>" type="text/css" />
	<link rel="stylesheet" href="<?php echo e(URL::asset('frontend/css/font-icons.css')); ?>" type="text/css" />
	<link rel="stylesheet" href="<?php echo e(URL::asset('frontend/css/animate.css')); ?>" type="text/css" />
	<link rel="stylesheet" href="<?php echo e(URL::asset('frontend/css/magnific-popup.css')); ?>" type="text/css" />
	<link rel="stylesheet" href="<?php echo e(URL::asset('frontend/css/swiper.css')); ?>" type="text/css" />
	<link rel="stylesheet" href="<?php echo e(URL::asset('frontend/css/custom.css')); ?>" type="text/css" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />

	<!-- Document Title
	============================================= -->
	<?php if($aplikasi->file_favicon): ?>
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset($aplikasi->file_favicon->url_stream)); ?>">
	<title><?php echo $__env->yieldContent('title'); ?> | <?php echo e($aplikasi->singkatan.' '.$aplikasi->daerah); ?></title>
	<?php endif; ?>
	<?php echo $__env->yieldPushContent('css'); ?>
</head>

<body class="stretched">

	<!-- Document Wrapper
	============================================= -->
	<div id="wrapper" class="clearfix">

		<?php echo $__env->make('layouts.frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php echo $__env->yieldContent('content'); ?>
		<?php echo $__env->make('layouts.frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


	</div><!-- #wrapper end -->

	<!-- Go To Top
	============================================= -->
	<div id="gotoTop" class="icon-angle-up"></div>

	<!-- JavaScripts
	============================================= -->
	<script src="<?php echo e(URL::asset('frontend/js/jquery.js')); ?>"></script>
	<script src="<?php echo e(URL::asset('frontend/js/plugins.min.js')); ?>"></script>

	<!-- Footer Scripts
	============================================= -->
	<script src="<?php echo e(URL::asset('frontend/js/functions.js')); ?>"></script>
	<?php echo $__env->yieldPushContent('js'); ?>
	<script>
	$(function() {
		$( "#side-navigation" ).tabs({ show: { effect: "fade", duration: 400 } });
	});
</script>

</body>
</html><?php /**PATH C:\xampp\htdocs\satudata\resources\views/layouts/frontend/main.blade.php ENDPATH**/ ?>