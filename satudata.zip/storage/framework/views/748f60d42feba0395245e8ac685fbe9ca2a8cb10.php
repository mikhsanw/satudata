<!-- Header
============================================= -->
<header id="header" class="header-size-sm">
	<div class="container">
		<div class="header-row flex-column flex-lg-row justify-content-center justify-content-lg-start">

			<!-- Logo
			============================================= -->
			<div id="logo" class="me-0 me-lg-auto">
			<?php if($aplikasi->file_logo): ?>
				<a href="<?php echo e(url('/')); ?>" class="standard-logo" data-dark-logo="<?php echo e(URL::asset($aplikasi->file_logo->url_stream)); ?>"><img src="<?php echo e(URL::asset($aplikasi->file_logo->url_stream)); ?>" alt="Logo"></a>
				<a href="<?php echo e(url('/')); ?>" class="retina-logo" data-dark-logo="<?php echo e(URL::asset($aplikasi->file_logo->url_stream)); ?>"><img src="<?php echo e(URL::asset($aplikasi->file_logo->url_stream)); ?>" alt="Logo"></a>
			<?php endif; ?>
			</div><!-- #logo end -->

			<div class="header-misc mb-4 mb-lg-0 order-lg-last">

				<ul class="header-extras me-0 me-sm-4">
					<li>
						<i class="i-plain icon-email3 m-0"></i>
						<div class="he-text">
							Email
							<span><?php echo $kontak->email?$kontak->filterkontak('email')->isi:''; ?></span>
						</div>
					</li>
					<li>
						<i class="i-plain icon-call m-0"></i>
						<div class="he-text">
							Kontak
							<span><?php echo $kontak->telp?$kontak->filterkontak('telp')->isi:''; ?></span>
						</div>
					</li>
				</ul>

			</div>

		</div>
	</div>

	<div id="header-wrap" class="border-top border-f5">
		<div class="container">
			<div class="header-row justify-content-between flex-row-reverse flex-lg-row">

				<div id="primary-menu-trigger">
					<svg class="svg-trigger" viewBox="0 0 100 100"><path d="m 30,33 h 40 c 3.722839,0 7.5,3.126468 7.5,8.578427 0,5.451959 -2.727029,8.421573 -7.5,8.421573 h -20"></path><path d="m 30,50 h 40"></path><path d="m 70,67 h -40 c 0,0 -7.5,-0.802118 -7.5,-8.365747 0,-7.563629 7.5,-8.634253 7.5,-8.634253 h 20"></path></svg>
				</div>

				<!-- Primary Navigation
				============================================= -->
				<nav class="primary-menu">

					<ul class="menu-container">
						<?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li class="menu-item">
							<a class="menu-link" href="<?php echo e(is_string($val) ? $val : '#'); ?>"><div><?php echo e($key); ?></div></a>
							<?php if(!is_string($val)): ?>
							<ul class="sub-menu-container" style="min-width: max-content">
								<?php $__currentLoopData = $val; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keydata => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if(count($data->children) > 3 && $keydata >= 10): ?>
										<?php echo $__env->make('layouts.frontend.menu',['data'=>$data,'mega'=>true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
									<?php else: ?>
										<?php echo $__env->make('layouts.frontend.menu',['data'=>$data], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
									<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</ul>
							<?php endif; ?>
						</li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</ul>

				</nav><!-- #primary-menu end -->

				<form class="top-search-form" action="search.html" method="get">
					<input type="text" name="q" class="form-control" value="" placeholder="Type &amp; Hit Enter.." autocomplete="off">
				</form>

			</div>

		</div>
	</div>
	<div class="header-wrap-clone"></div>
</header><!-- #header end --><?php /**PATH C:\xampp\htdocs\satudata\resources\views/layouts/frontend/header.blade.php ENDPATH**/ ?>