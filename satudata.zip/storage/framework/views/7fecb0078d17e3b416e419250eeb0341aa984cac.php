  <!-- ======= Header ======= -->
  <header id="header" class="d-flex flex-column justify-content-center">

    <nav id="navbar" class="navbar nav-menu">
      <ul>
        <li><a href="<?php echo e(url('')); ?>" class="nav-link scrollto active"><i class="bx bx-home"></i> <span>Home</span></a></li>
        <li><a href="<?php echo e(url('')); ?>#about" class="nav-link scrollto"><i class="bx bx-book-bookmark"></i> <span>Satu Data</span></a></li>
        <li><a href="<?php echo e(url('')); ?>#resume" class="nav-link scrollto"><i class="bx bx-calendar"></i> <span>Jenis Data</span></a></li>
        <li><a href="<?php echo e(url('')); ?>#services" class="nav-link scrollto"><i class="bx bx-data"></i> <span>Data Sektoral</span></a></li>
        <li><a href="<?php echo e(url('')); ?>#portfolio" class="nav-link scrollto"><i class="bx bx-book-content"></i> <span>Publikasi</span></a></li>
        <li><a href="<?php echo e(url('https://ppid.bengkaliskab.go.id/web/link/permohonan-informasi-publik')); ?>#data" target="_blank"><i class="bx bx-food-menu"></i> <span>Permohonan Data</span></a></li>
        <li><a href="<?php echo e(url('')); ?>#contact" class="nav-link scrollto"><i class="bx bx-envelope"></i> <span>Kontak Kami</span></a></li>
        <li><a href="<?php echo e(url('cari')); ?>#cari" class="nav-link scrollto"><i class="bx bx-search"></i> <span>Pencarian</span></a></li>
      </ul>
    </nav><!-- .nav-menu -->

  </header><!-- End Header --><?php /**PATH C:\xampp\htdocs\satudata\resources\views/frontend/partials/header.blade.php ENDPATH**/ ?>