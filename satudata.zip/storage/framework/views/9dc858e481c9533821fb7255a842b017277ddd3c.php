<li class="<?php echo e($mn->active($mn->kode)); ?>">
    <a href="<?php echo e(count($mn->children) > 0 ? '#' : url(ltrim($url_admin.'/'.$mn->link, '/'))); ?>" title="<?php echo e($mn->nama); ?>" data-filter-tags="<?php echo e($mn->nama); ?>">
        <i class="<?php echo e($mn->icon); ?>"></i>
        <span class="nav-link-text <?php echo e($mn->kode); ?>" data-i18n="nav.<?php echo e($mn->kode); ?>"><?php echo e($mn->nama); ?></span>
    </a>
    <?php if(count($mn->children) > 0): ?>
        <ul style="background: #2f4b5d">
            <?php $__currentLoopData = $mn->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($sub->tampil == 1 && $sub->status == 1): ?>
                    <?php if($sub->checkAksesmenu(Auth::user()->aksesgrup_id)): ?>
                        <?php echo $__env->make('backend.home.sidebar_item.submenu', ['mn'=>$sub], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>
</li>
<?php /**PATH C:\xampp\htdocs\satudata\resources\views/backend/home/sidebar_item/submenu.blade.php ENDPATH**/ ?>