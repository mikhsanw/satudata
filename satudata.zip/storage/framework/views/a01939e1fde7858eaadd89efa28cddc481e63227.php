
<?php $__env->startPush('title',ucwords(strtolower($halaman->nama))); ?>
<?php $__env->startPush('header',ucwords(strtolower($halaman->nama))); ?>
<?php $__env->startSection('content'); ?>
<div class="panel-container show">
	<div class="panel-content">
		<table id="" class="table table-bordered table-hover table-striped table-responsive">
		<thead class="bg-primary-600">
				<tr>
					<td rowspan="2" style="vertical-align : middle;text-align:center;">No</td>
					<td rowspan="2" style="vertical-align : middle;text-align:center;">Elemen / Sub Elemen</td>
					<td rowspan="2" style="vertical-align : middle;text-align:center;">Satuan</td>
					<td rowspan="2" style="vertical-align : middle;text-align:center;">Produsen Data</td>
					<td rowspan="2" style="vertical-align : middle;text-align:center;">Ketersediaan Data</td>
					<td colspan="<?php echo e(count($tahuns)); ?>" style="vertical-align : middle;text-align:center;">Tahun Produksi</td>
					<td rowspan="2" style="vertical-align : middle;text-align:center;">Catatan</td>
				</tr>
				<tr>
					<?php $__currentLoopData = $tahuns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $th): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<td style="vertical-align : middle;text-align:center;"><?php echo e($tahun[]=$th); ?></td>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tr>
			</thead>
			<tbody>
				<?php $i=1; ?>
				<?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td style="font-weight: bold; text-align: center;"><?php echo e($i); ?></td>
						<td style="font-weight: bold;"><?php echo e($data->nama??''); ?></td>
						<td><?php echo e($data->satuan??''); ?></td>
						<td><?php echo e(($data->opd->nama??'')); ?></td>
						<td><?php echo e((count($data->data)>0)?'Ada':''); ?></td>
						<?php $__currentLoopData = $tahun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $th): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<td><?php echo e($elemen->filterjumlah($data->id??'',$th)->jumlah??''); ?></td>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<td><?php echo e($data->keterangan??''); ?></td>
					</tr>
					<?php $tes=''; ?>
					<?php $__currentLoopData = $data->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php echo $__env->make('backend.laporan.loop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php $i++; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<?php echo $__env->make('backend.home.datatable-js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script type="text/javascript" src="<?php echo e(URL::asset(config('master.aplikasi.author').'/home/'.$halaman->link.'/'.$halaman->kode.'/jquery-crud.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset(config('master.aplikasi.author').'/'.$halaman->kode.'/datatables.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('backend/js/formplugins/select2/select2.bundle.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('css'); ?>
<link rel="stylesheet" media="screen, print" href="<?php echo e(asset('backend/css/formplugins/summernote/summernote.css')); ?>">
<link rel="stylesheet" media="screen, print" href="<?php echo e(URL::asset('backend/css/formplugins/select2/select2.bundle.css')); ?>">
<?php echo $__env->make('backend.home.datatable-css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.home.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\satudata\resources\views/backend/laporan/index.blade.php ENDPATH**/ ?>