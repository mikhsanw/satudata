
<?php $__env->startPush('title','User'); ?>
<?php $__env->startPush('header','User'); ?>
<?php $__env->startPush('tombol'); ?>
<a href="#tambah" class="btn btn-sm btn-primary tambah">
	Tambah  <i class="fa fa-plus-circle"></i>
</a>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="panel-container show">
	<div class="panel-content">
		<table id="datatable" class="table table-bordered table-hover table-striped w-100">
			<thead class="bg-primary-600">
				<tr>
					<th class="text-center">NIP</th>
					<th >Nama</th>
					<th >E-Mail</th>
					<th class="text-center">Akses Grup</th>
					<th class="text-center">Level</th>
					<th class="text-center wid-10">Aksi</th>
				</tr>
			</thead>
		</table>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<?php echo $__env->make('backend.home.datatable-js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script type="text/javascript" src="<?php echo e(URL::asset(config('master.aplikasi.author').'/user/jquery.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset(config('master.aplikasi.author').'/user/datatables.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('css'); ?>
<?php echo $__env->make('backend.home.datatable-css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.home.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\satudata\resources\views/backend/user/index.blade.php ENDPATH**/ ?>