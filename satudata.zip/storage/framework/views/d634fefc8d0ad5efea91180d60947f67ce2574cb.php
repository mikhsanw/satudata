<?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-lg-6 table-responsive">
        <ul class="list-group m-1">
            <li class="list-group-item">
                <?php echo Form::checkbox('menu[]', $mn->id, $mn->checkAksesmenu($aksesgrup->id), array('id' => 'icheck-input menu'.$mn->id, 'menu-id' => $mn->id, 'class' => 'icheck-input menu'.$mn->id)); ?>

                &nbsp;&nbsp;
                <label for="icheck-input menu<?php echo e($mn->id); ?>"><?php echo e($mn->nama); ?></label>
                <?php if(count($mn->children)): ?>
                    <ul class="list-group ml-3">
                        <?php $__currentLoopData = $mn->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cmn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->make('backend.aksesmenu.menu.sub-menu',['mn'=>$cmn,'aksesgrup'=>$aksesgrup], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </li>
        </ul>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\satudata\resources\views/backend/aksesmenu/menu/menu.blade.php ENDPATH**/ ?>