<?php $tes=$tes.('.'.$key+1); ?>
<tr>
    <td><?php echo e('1'.$tes); ?> </td>
    <td><?php echo e($item->nama); ?></td>
    <td><?php echo e($item->satuan??''); ?></td>
    <td><?php echo e(($data->opd->nama??'')); ?></td>
    <td><?php echo e((count($item->data)>0)?'Ada':''); ?></td>
    <?php $__currentLoopData = $tahun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $th): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <td><?php echo e($elemen->filterjumlah($item->id??'',$th)->jumlah??''); ?></td>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <td><?php echo e($item->keterangan??''); ?></td>
    <td>
    <?php if(count($item->data)>0): ?>
        <a href="#modalChart" data-lightbox="inline" class="button button-large button-rounded modalChart" title="<?php echo e($item->nama??''); ?>" id="<?php echo e($item->id); ?>"><i class="fa fa-bar-chart" style="font-size:25px;color:red"></i></a>
    <?php endif; ?>
    </td>
</tr>
<?php $__currentLoopData = $item->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo $__env->make('frontend.beranda.cari.loop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\satudata\resources\views/frontend/beranda/cari/loop.blade.php ENDPATH**/ ?>