<!-- ======= Footer ======= -->
<footer id="footer">
  <div class="container">
    <h3>Bidang Statistik</h3>
    <p>Bidang Statistik Dinas Komunikasi Informatika dan Statistik Kabupaten Bengkalis Memiliki Fungsi Sebagai Satu Data Sektoral Kabupaten Bengkalis dan juga sebagai penyebarluasan data, hal ini sesuai dengan Perpres no 39 Tahun 2019 tentang Satu Data Indonesia serta di perkuat dengan adanya Perbup Bupati Bengkalis no 5 tahun 2019. Bidang Statistik Dinas Komunikasi Informatika dan Statistik Kabupaten Bengkalis yang saat ini dipimpin oleh Bapak Azmar, S.Kom, MIP.</p>
    <center><a href="https://bengkaliskab.go.id" target="_blank"><img src="<?php echo e(asset('images/Kabupaten Bengkalis Bermasa.png')); ?>" alt=""></a></center>
    <br>
    <div class="social-links">
      <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
      <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
      <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
      <a href="#" class="youtube"><i class="bx bxl-youtube"></i></a>
    </div>
    <div class="copyright">
      &copy; Copyright <strong><span>2023</span></strong>. All Rights Reserved
    </div>
    <div class="credits">
      <!-- All the links in the footer should remain intact. -->
      <!-- You can delete the links only if you purchased the pro version. -->
      <!-- Licensing information: [license-url] -->
      <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/free-html-bootstrap-template-my-resume/ -->
      Designed by <a href="https://bengkaliskab.go.id/">TIM IT PBE Diskominfotik Kabupaten Bengkalis</a>
    </div>
  </div>
</footer><!-- End Footer --><?php /**PATH C:\xampp\htdocs\satudata\resources\views/frontend/partials/footer.blade.php ENDPATH**/ ?>