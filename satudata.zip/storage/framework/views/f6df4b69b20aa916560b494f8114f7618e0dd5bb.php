<table id="datatable" class="table table-bordered table-hover table-striped table-responsive">
    <thead class="bg-primary-600">
    <tr>
        <td rowspan="2" style="vertical-align : middle;text-align:center;font-weight: bold;">No</td>
        <td rowspan="2" style="vertical-align : middle;text-align:center;font-weight: bold;">Elemen / Sub Elemen</td>
        <td rowspan="2" style="vertical-align : middle;text-align:center;font-weight: bold;">Satuan</td>
        <td rowspan="2" style="vertical-align : middle;text-align:center;font-weight: bold;">Produsen Data</td>
        <td rowspan="2" style="vertical-align : middle;text-align:center;font-weight: bold;">Ketersediaan Data</td>
        <td colspan="<?php echo e(count($tahuns)); ?>" style="vertical-align : middle;text-align:center;font-weight: bold;">Tahun Produksi</td>
        <td rowspan="2" style="vertical-align : middle;text-align:center;font-weight: bold;">Catatan</td>
    </tr>
    <tr>
        <?php $__currentLoopData = $tahuns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $th): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <td style="vertical-align : middle;text-align:center;font-weight: bold;"><?php echo e($tahun[]=$th); ?></td>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tr>
    </thead>
    <tbody>
        <tr>
        <td style="font-weight: bold; text-align: center;">1</td>
        <td style="font-weight: bold;"><?php echo e($datas->nama??''); ?></td>
        <td><?php echo e($datas->satuan??''); ?></td>
        <td><?php echo e(($datas->opd->nama??'')); ?></td>
        <td><?php echo e((count($datas->data)>0)?'Ada':''); ?></td>
        <?php $__currentLoopData = $tahun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $th): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <td><?php echo e($elemen->filterjumlah($datas->id??'',$th)->jumlah??''); ?></td>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <td><?php echo e($datas->keterangan??''); ?></td>
        </tr>
        <?php $tes=''; ?>
        <?php $__currentLoopData = $datas->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('frontend.beranda.cari.loop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\xampp\htdocs\satudata\resources\views/frontend/beranda/cari/export.blade.php ENDPATH**/ ?>